/* ===== VCL interaction layer (ported from preferred homepage design) ===== */
// Custom Cursor
const cursor = document.getElementById('cursor');
const cursorRing = document.getElementById('cursorRing');
let mouseX = 0, mouseY = 0, ringX = 0, ringY = 0;

document.addEventListener('mousemove', (e) => {
  mouseX = e.clientX;
  mouseY = e.clientY;
  cursor.style.left = mouseX + 'px';
  cursor.style.top = mouseY + 'px';
});

function animateRing() {
  ringX += (mouseX - ringX) * 0.12;
  ringY += (mouseY - ringY) * 0.12;
  cursorRing.style.left = ringX + 'px';
  cursorRing.style.top = ringY + 'px';
  requestAnimationFrame(animateRing);
}
animateRing();

document.querySelectorAll('a, button, .problem-card, .service-item, .diff-pillar').forEach(el => {
  el.addEventListener('mouseenter', () => {
    cursor.classList.add('hover');
    cursorRing.classList.add('hover');
  });
  el.addEventListener('mouseleave', () => {
    cursor.classList.remove('hover');
    cursorRing.classList.remove('hover');
  });
});

// Hide custom cursor over the form so inputs remain interactive
const formPanelEl = document.querySelector('.contact-form-panel');
if (formPanelEl) {
  formPanelEl.addEventListener('mouseenter', () => {
    cursor.style.opacity = '0';
    cursorRing.style.opacity = '0';
    document.body.style.cursor = 'auto';
  });
  formPanelEl.addEventListener('mouseleave', () => {
    cursor.style.opacity = '1';
    cursorRing.style.opacity = '1';
    document.body.style.cursor = 'none';
  });
}

// ─── Contact Form Submission ───────────────────────────────────────
// Uses Web3Forms, free, no backend needed, sends to any email address.
// Access key is tied to mark@vanguardcreativelabs.com
const vclForm = document.getElementById('vclForm');
const formSuccess = document.getElementById('formSuccess');
const formError = document.getElementById('formError');
const submitBtn = document.getElementById('submitBtn');
const submitText = document.getElementById('submitText');

if (vclForm) {
  vclForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Clear previous error states
    document.querySelectorAll('.form-input, .form-select, .form-textarea').forEach(el => {
      el.classList.remove('error');
    });
    formError.classList.remove('visible');

    // Client-side validation
    const required = vclForm.querySelectorAll('[required]');
    let valid = true;
    required.forEach(field => {
      if (!field.value.trim()) {
        field.classList.add('error');
        valid = false;
      }
    });

    const emailField = document.getElementById('email');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (emailField.value && !emailRegex.test(emailField.value)) {
      emailField.classList.add('error');
      valid = false;
    }

    if (!valid) {
      formError.textContent = 'Please fill in all required fields before submitting.';
      formError.classList.add('visible');
      return;
    }

    // Loading state
    submitText.textContent = 'Sending...';
    submitBtn.disabled = true;

    // Build form data for Web3Forms
    const formData = {
      access_key: 'REPLACE_WITH_WEB3FORMS_KEY', // → get free key at web3forms.com using mark@vanguardcreativelabs.com
      subject: `Strategy Call Request, ${document.getElementById('firstName').value} ${document.getElementById('lastName').value}`,
      from_name: `${document.getElementById('firstName').value} ${document.getElementById('lastName').value}`,
      reply_to: document.getElementById('email').value,
      to: 'mark@vanguardcreativelabs.com',
      name: `${document.getElementById('firstName').value} ${document.getElementById('lastName').value}`,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value || 'Not provided',
      business: document.getElementById('business').value,
      message: document.getElementById('message').value,
      botcheck: ''
    };

    try {
      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(formData)
      });

      const result = await response.json();

      if (result.success) {
        // Show success state
        vclForm.classList.add('hidden');
        formSuccess.classList.add('visible');
      } else {
        throw new Error(result.message || 'Submission failed');
      }
    } catch (err) {
      submitText.textContent = 'Request Strategy Call';
      submitBtn.disabled = false;
      formError.textContent = 'Something went wrong. Please email us directly: mark@vanguardcreativelabs.com';
      formError.classList.add('visible');
    }
  });

  // Remove error state on input
  vclForm.querySelectorAll('.form-input, .form-select, .form-textarea').forEach(el => {
    el.addEventListener('input', () => el.classList.remove('error'));
  });
}


// Current year in footers
document.querySelectorAll('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });

// Nav scroll
const nav = document.getElementById('nav');
window.addEventListener('scroll', () => {
  if (window.scrollY > 80) {
    nav.classList.add('scrolled');
  } else {
    nav.classList.remove('scrolled');
  }
});

// Scroll Progress
const scrollProgress = document.getElementById('scrollProgress');
window.addEventListener('scroll', () => {
  const total = document.documentElement.scrollHeight - window.innerHeight;
  const progress = (window.scrollY / total) * 100;
  scrollProgress.style.width = progress + '%';
});

// Scroll Reveal, fallback only when GSAP is unavailable (GSAP drives reveals otherwise)
if (!window.gsap) {
  const revealEls = document.querySelectorAll('.reveal, .reveal-left');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });

  revealEls.forEach(el => revealObserver.observe(el));
}

// Timeline Progress Animation, fallback only (GSAP scrubs the line when present)
if (!window.gsap) {
  const timelineEl = document.getElementById('timelineProgress');
  const timelineObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        timelineEl.style.width = '100%';
      }
    });
  }, { threshold: 0.3 });

  if (timelineEl) timelineObserver.observe(timelineEl.closest('.process-timeline'));
}

// GHL embed loaded via external script tag

// Smooth anchor scrolling, fallback only (Lenis handles anchors when GSAP/Lenis present)
if (!window.gsap) {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        const offset = 80;
        const top = target.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    });
  });
}

(function () {
  'use strict';

  var prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var isTouch        = window.matchMedia('(hover: none), (pointer: coarse)').matches;
  var isMobile       = window.matchMedia('(max-width: 960px)').matches;

  /* ---------- Mobile navigation (works with or without GSAP) ---------- */
  (function navMenu() {
    var toggle = document.getElementById('navToggle');
    var links  = document.getElementById('navLinks');
    if (!toggle || !links) return;
    /* iOS Safari ignores body{overflow:hidden}, so the page kept scrolling
       behind the drawer once you were away from the top. Pin the body at
       its current offset instead, and restore the position on close. */
    var lockedAt = 0;
    function lock() {
      lockedAt = window.scrollY || window.pageYOffset || 0;
      document.body.style.top = (-lockedAt) + 'px';
      document.body.classList.add('nav-open');
    }
    function unlock() {
      document.body.classList.remove('nav-open');
      document.body.style.top = '';
      window.scrollTo(0, lockedAt);
    }
    function close() {
      toggle.classList.remove('open');
      links.classList.remove('open');
      unlock();
      toggle.setAttribute('aria-expanded', 'false');
    }
    toggle.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      toggle.classList.toggle('open', open);
      if (open) lock(); else unlock();
      toggle.setAttribute('aria-expanded', String(open));
    });
    links.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', close);
    });
  })();

  var gsap = window.gsap;
  var ScrollTrigger = window.ScrollTrigger;

  /* ---------- Graceful fallback if GSAP failed to load ---------- */
  if (!gsap || !ScrollTrigger) {
    document.querySelectorAll('.reveal, .reveal-left').forEach(function (el) {
      el.classList.add('revealed');
    });
    initHeroNetwork(); // Three.js still attempted independently
    return;
  }

  gsap.registerPlugin(ScrollTrigger);
  document.documentElement.classList.add('js-anim');

  /* ---------- Native scroll (Lenis smooth-scroll removed per user request) ---------- */
  var lenis = null;

  /* Anchor links routed through Lenis (offset for fixed nav) */
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var id = this.getAttribute('href');
      if (id.length < 2) return;
      var target = document.querySelector(id);
      if (!target) return;
      e.preventDefault();
      if (lenis) lenis.scrollTo(target, { offset: -80, duration: 1.2 });
      else window.scrollTo({ top: target.getBoundingClientRect().top + window.scrollY - 80, behavior: 'smooth' });
    });
  });

  /* ---------- Reduced motion: reveal everything, skip choreography ---------- */
  if (prefersReduced) {
    gsap.set('.reveal, .reveal-left', { clearProps: 'all', opacity: 1, x: 0, y: 0 });
    initHeroNetwork();
    return;
  }

  /* ---------- HERO intro timeline ---------- */
  var heroTl = gsap.timeline({ defaults: { ease: 'power3.out' } });
  gsap.set('.hero-headline .line-inner', { yPercent: 118 });
  gsap.set(['.hero-eyebrow', '.hero-body', '.hero-actions', '.hero-stats'], { opacity: 0, y: 26 });

  heroTl
    .to('.hero-eyebrow', { opacity: 1, y: 0, duration: 0.8 }, 0.2)
    .to('.hero-headline .line-inner', { yPercent: 0, duration: 1.1, stagger: 0.1 }, 0.3)
    .to('.hero-body', { opacity: 1, y: 0, duration: 0.9 }, 0.7)
    .to('.hero-actions', { opacity: 1, y: 0, duration: 0.9 }, 0.85)
    .to('.hero-stats', { opacity: 1, y: 0, duration: 0.9 }, 1.0);

  /* ---------- Generic scroll reveals (batched, staggered) ---------- */
  if (document.querySelector('.reveal')) {
    gsap.set('.reveal', { opacity: 0, y: 48 });
    ScrollTrigger.batch('.reveal', {
      start: 'top 86%',
      onEnter: function (els) {
        gsap.to(els, { opacity: 1, y: 0, duration: 0.95, ease: 'power3.out', stagger: 0.12, overwrite: true });
      }
    });
  }
  if (document.querySelector('.reveal-left')) {
    gsap.set('.reveal-left', { opacity: 0, x: -48 });
    ScrollTrigger.batch('.reveal-left', {
      start: 'top 86%',
      onEnter: function (els) {
        gsap.to(els, { opacity: 1, x: 0, duration: 0.95, ease: 'power3.out', stagger: 0.12, overwrite: true });
      }
    });
  }

  /* ---------- Section heading character-line drift ---------- */
  gsap.utils.toArray('.section-heading').forEach(function (h) {
    gsap.from(h, {
      scrollTrigger: { trigger: h, start: 'top 88%' },
      yPercent: 12, opacity: 0, duration: 1, ease: 'power3.out'
    });
  });

  /* ---------- Animated stat counters ---------- */
  gsap.utils.toArray('.hero-stat-number').forEach(function (el) {
    var node = el.firstChild;                       // leading text node, e.g. "12", "$2", "98"
    if (!node || node.nodeType !== 3) return;
    var raw = node.textContent.trim();
    var prefix = (raw.match(/^[^0-9]+/) || [''])[0];
    var target = parseInt(raw.replace(/[^0-9]/g, ''), 10) || 0;
    var counter = { v: 0 };
    ScrollTrigger.create({
      trigger: el, start: 'top 92%', once: true,
      onEnter: function () {
        gsap.to(counter, {
          v: target, duration: 1.6, ease: 'power2.out',
          onUpdate: function () { node.textContent = prefix + Math.round(counter.v); }
        });
      }
    });
  });

  /* ---------- Process timeline: scrub the progress line + reveal steps ---------- */
  var timeline = document.querySelector('.process-timeline');
  if (timeline) {
    gsap.fromTo('#timelineProgress', { width: '0%' }, {
      width: '100%', ease: 'none',
      scrollTrigger: { trigger: timeline, start: 'top 65%', end: 'bottom 80%', scrub: true }
    });
    gsap.utils.toArray('.process-step').forEach(function (step, i) {
      gsap.from(step, {
        scrollTrigger: { trigger: step, start: 'top 85%' },
        opacity: 0, x: -40, duration: 0.9, ease: 'power3.out', delay: (i % 2) * 0.05
      });
    });
  }

  /* ---------- Parallax accents ---------- */
  gsap.utils.toArray('.about-visual-block, .booking-guarantee, .problems-cta-block').forEach(function (el) {
    gsap.to(el, {
      yPercent: -8, ease: 'none',
      scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: true }
    });
  });

  /* ---------- Magnetic buttons removed per user request (colour-only hovers) ---------- */

  /* ---------- Hero content parallax on scroll ---------- */
  gsap.to('.hero-left', {
    yPercent: 14, ease: 'none',
    scrollTrigger: { trigger: '#hero', start: 'top top', end: 'bottom top', scrub: true }
  });

  /* ---------- Three.js network hero ---------- */
  initHeroNetwork();

  ScrollTrigger.refresh();

  /* =========================================================
     Three.js, "digital infrastructure" node network
  ========================================================= */
  function initHeroNetwork() {
    var canvas = document.getElementById('heroCanvas');
    var hero = document.getElementById('hero');
    if (!canvas || !hero || !window.THREE) return;

    var THREE = window.THREE;
    var renderer;
    try {
      renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true });
    } catch (err) { return; }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

    var scene = new THREE.Scene();
    var camera = new THREE.PerspectiveCamera(58, 1, 0.1, 100);
    camera.position.z = 16;

    var group = new THREE.Group();
    scene.add(group);

    var N = isMobile ? 70 : 130;
    var radius = isMobile ? 7.5 : 9.5;
    var pts = [];
    var posArr = [];
    for (var i = 0; i < N; i++) {
      var v = new THREE.Vector3(Math.random() * 2 - 1, Math.random() * 2 - 1, Math.random() * 2 - 1);
      v.normalize().multiplyScalar(Math.cbrt(Math.random()) * radius);
      pts.push(v);
      posArr.push(v.x, v.y, v.z);
    }
    var pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute('position', new THREE.Float32BufferAttribute(posArr, 3));
    var pMat = new THREE.PointsMaterial({ color: 0xB8956A, size: 0.16, transparent: true, opacity: 0.95, sizeAttenuation: true });
    group.add(new THREE.Points(pGeo, pMat));

    var thresh = isMobile ? 4.6 : 4.0;
    var lineArr = [];
    for (var a = 0; a < N; a++) {
      for (var b = a + 1; b < N; b++) {
        if (pts[a].distanceTo(pts[b]) < thresh) {
          lineArr.push(pts[a].x, pts[a].y, pts[a].z, pts[b].x, pts[b].y, pts[b].z);
        }
      }
    }
    var lGeo = new THREE.BufferGeometry();
    lGeo.setAttribute('position', new THREE.Float32BufferAttribute(lineArr, 3));
    group.add(new THREE.LineSegments(lGeo, new THREE.LineBasicMaterial({ color: 0xB8956A, transparent: true, opacity: 0.16 })));

    var core = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.IcosahedronGeometry(3.1, 1)),
      new THREE.LineBasicMaterial({ color: 0xD4AF8A, transparent: true, opacity: 0.32 })
    );
    group.add(core);

    function resize() {
      var w = hero.clientWidth, h = hero.clientHeight;
      if (!w || !h) return;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    }
    resize();
    window.addEventListener('resize', resize);

    var tmx = 0, tmy = 0, mx = 0, my = 0;
    window.addEventListener('mousemove', function (e) {
      tmx = e.clientX / window.innerWidth - 0.5;
      tmy = e.clientY / window.innerHeight - 0.5;
    });

    if (window.ScrollTrigger) {
      window.ScrollTrigger.create({
        trigger: '#hero', start: 'top top', end: 'bottom top', scrub: true,
        onUpdate: function (self) {
          group.position.y = self.progress * 6;
          pMat.opacity = 0.95 * (1 - self.progress * 0.75);
        }
      });
    }

    canvas.classList.add('is-ready');

    if (prefersReduced) { resize(); renderer.render(scene, camera); return; }

    (function render() {
      mx += (tmx - mx) * 0.05;
      my += (tmy - my) * 0.05;
      group.rotation.y += 0.0012;
      group.rotation.x = my * 0.45;
      group.rotation.z = mx * 0.18;
      core.rotation.y -= 0.0016;
      camera.position.x = mx * 4;
      camera.position.y = -my * 4;
      camera.lookAt(scene.position);
      renderer.render(scene, camera);
      requestAnimationFrame(render);
    })();
  }
})();

/* =========================================================
   3D LOGO SPHERE, Fibonacci-distributed, billboarded logos
   orbiting a centred bronze V mark (Three.js).
========================================================= */
(function initLogoSphere(){
  var THREE = window.THREE;
  var canvas = document.getElementById('logoSphere');
  var section = document.getElementById('stack');
  if (!canvas || !section) return;
  var imgEls = Array.prototype.slice.call(section.querySelectorAll('[data-logo]'));
  if (!imgEls.length) return;

  var prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (!THREE) { section.classList.add('no-webgl'); return; }
  var renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true });
  } catch (e) { section.classList.add('no-webgl'); return; }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

  var scene = new THREE.Scene();
  var FOV = 45;
  var camDist = 10;
  var camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 100);
  camera.position.z = camDist;

  var group = new THREE.Group();   // the rotating sphere of logos
  scene.add(group);

  var N = imgEls.length;
  var GA = Math.PI * (3 - Math.sqrt(5));   // golden angle
  function fibPoint(i) {
    // (i + 0.5)/N keeps points OFF the exact poles, so every logo is off the
    // rotation axis and actually orbits (nothing gets stuck at top/bottom).
    var y = 1 - ((i + 0.5) / N) * 2;
    var r = Math.sqrt(Math.max(0, 1 - y * y));
    var theta = GA * i;
    return new THREE.Vector3(Math.cos(theta) * r, y, Math.sin(theta) * r);
  }
  function easeOut(x){ return 1 - Math.pow(1 - x, 3); }

  var R = 3, spriteScale = 0.5, bobWorld = 0.05, W = 1, H = 1;
  function worldHeight(){ return 2 * camDist * Math.tan((FOV * Math.PI / 180) / 2); }
  function computeSizing(){
    W = canvas.clientWidth || section.clientWidth || window.innerWidth;
    H = canvas.clientHeight || section.clientHeight || window.innerHeight;
    var minDim = Math.min(W, H);
    var Hw = worldHeight();
    R = Hw * ((0.38 * minDim) / H);
    var logoPx = Math.max(57, minDim * 0.09);   /* +25% larger logos */
    spriteScale = Hw * (logoPx / H);
    bobWorld = Hw * (6 / H);
  }
  computeSizing();

  // ---- Build a soft, drop-shadowed texture from each logo (SVG or PNG) ----
  function makeTexture(src, withShadow){
    return new Promise(function(resolve){
      var img = new Image();
      img.onload = function(){
        var S = 256;
        var c = document.createElement('canvas'); c.width = c.height = S;
        var g = c.getContext('2d');
        var iw = img.naturalWidth || S, ih = img.naturalHeight || S;
        var pad = withShadow ? S * 0.18 : S * 0.04;
        var max = S - pad * 2;
        var sc = Math.min(max / iw, max / ih);
        var w = iw * sc, h = ih * sc;
        if (withShadow) { g.shadowColor = 'rgba(0,0,0,0.55)'; g.shadowBlur = S * 0.07; g.shadowOffsetY = S * 0.025; }
        g.drawImage(img, (S - w) / 2, (S - h) / 2, w, h);
        var tex = new THREE.CanvasTexture(c);
        tex.anisotropy = renderer.capabilities.getMaxAnisotropy ? renderer.capabilities.getMaxAnisotropy() : 4;
        if (THREE.SRGBColorSpace) tex.colorSpace = THREE.SRGBColorSpace;
        tex.needsUpdate = true;
        resolve(tex);
      };
      img.onerror = function(){ resolve(null); };
      img.src = src;
    });
  }

  var sprites = [], vSprite = null;
  var started = false, startT = 0;
  var clock = new THREE.Clock();

  function placeAll(){
    for (var i = 0; i < sprites.length; i++){
      sprites[i].userData.base = fibPoint(i).multiplyScalar(R);
    }
    if (vSprite) { var vs = R * 0.375; vSprite.scale.set(vs, vs, 1); }
  }

  function resize(){
    W = canvas.clientWidth || section.clientWidth; H = canvas.clientHeight || section.clientHeight;
    if (!W || !H) return;
    renderer.setSize(W, H, false);
    camera.aspect = W / H; camera.updateProjectionMatrix();
    computeSizing();
    placeAll();
  }

  function render(){
    var t = clock.getElapsedTime();
    if (!prefersReduced) group.rotation.y = t * (2 * Math.PI / 50);

    if (vSprite){
      var vk = prefersReduced ? 1 : (started ? Math.min((t - startT) / 0.8, 1) : 0);
      vSprite.material.opacity = easeOut(vk);
    }
    var theta = group.rotation.y;
    var sinT = Math.sin(theta), cosT = Math.cos(theta);
    for (var i = 0; i < sprites.length; i++){
      var sp = sprites[i], k;
      if (prefersReduced) k = 1;
      else if (!started) k = 0;
      else { var local = t - startT - i * 0.12; k = local <= 0 ? 0 : Math.min(local / 0.6, 1); }
      k = easeOut(k);
      var b = sp.userData.base;
      // depth factor from the world-space z after the group's Y rotation (1 = front/near, 0 = back/far)
      var wz = -b.x * sinT + b.z * cosT;
      var f = (wz / R + 1) / 2; if (f < 0) f = 0; else if (f > 1) f = 1;
      var depthScale = 0.74 + 0.46 * f;   // back logos smaller, front logos larger
      var depthOpac  = 0.32 + 0.68 * f;   // back fainter; closest fully opaque
      sp.material.opacity = k * depthOpac;
      var s = (0.7 + 0.3 * k) * spriteScale * depthScale;
      sp.scale.set(s, s, 1);
      var bob = prefersReduced ? 0 : Math.sin(t * (2 * Math.PI / 4) + sp.userData.phase) * bobWorld;
      sp.position.set(b.x, b.y + bob, b.z);
    }
    renderer.render(scene, camera);
    if (prefersReduced) return;          // single static frame
    requestAnimationFrame(render);
  }

  // ---- Load all textures, then build the scene ----
  var section_vmark = section.getAttribute('data-vmark');
  var jobs = imgEls.map(function(el){ return makeTexture(el.getAttribute('src'), true); });
  jobs.push(makeTexture(section_vmark, false));

  Promise.all(jobs).then(function(texs){
    var vTex = texs.pop();
    texs.forEach(function(tex, i){
      if (!tex) return;
      var mat = new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 0, depthTest: false, depthWrite: false });
      var sp = new THREE.Sprite(mat);
      sp.userData.base = fibPoint(i).multiplyScalar(R);
      sp.userData.phase = i * 0.9;                 // phase-offset bob so they don't move in unison
      sp.scale.set(spriteScale * 0.7, spriteScale * 0.7, 1);
      group.add(sp); sprites.push(sp);
    });
    if (vTex){
      var vMat = new THREE.SpriteMaterial({ map: vTex, transparent: true, opacity: 0, depthTest: false, depthWrite: false });
      vSprite = new THREE.Sprite(vMat);
      var vs = R * 0.375; vSprite.scale.set(vs, vs, 1);
      vSprite.position.set(0, 0, 0);               // sphere-centre depth, fixed (does not rotate)
      vSprite.renderOrder = 0;
      scene.add(vSprite);
    }
    resize();
    render();

    // Start the staggered bloom when the section scrolls into view
    function start(){ if (started) return; started = true; startT = clock.getElapsedTime(); }
    window.__startSphere = start;
    window.__sphereForceShow = function(){            // debug helper for static previews
      started = true; startT = clock.getElapsedTime() - 100;
      var th = group.rotation.y, sT = Math.sin(th), cT = Math.cos(th);
      sprites.forEach(function(sp){
        var b = sp.userData.base; var wz = -b.x * sT + b.z * cT;
        var f = (wz / R + 1) / 2; if (f < 0) f = 0; else if (f > 1) f = 1;
        sp.material.opacity = 0.32 + 0.68 * f;
        var s = spriteScale * (0.74 + 0.46 * f); sp.scale.set(s, s, 1);
      });
      if (vSprite) vSprite.material.opacity = 1;
      renderer.render(scene, camera);
    };
    if (prefersReduced) { start(); }
    else {
      try {
        var io = new IntersectionObserver(function(es){
          es.forEach(function(e){ if (e.isIntersecting) start(); });
        }, { threshold: 0.12 });
        io.observe(section);
      } catch (e) { start(); }
      // Fallback: if the section is already near the viewport on load, start anyway
      var r = section.getBoundingClientRect();
      if (r.top < window.innerHeight * 1.2) setTimeout(start, 400);
    }
  });

  var rt;
  window.addEventListener('resize', function(){ clearTimeout(rt); rt = setTimeout(resize, 150); });
})();

/* ============================================================
   SPEC HERO, rotating wireframe solid inside the frame
   Geometry is chosen per page via data-solid on .spec-hero
   ============================================================ */
(function () {
  var hero = document.querySelector('.spec-hero');
  if (!hero || !window.THREE) return;
  var cv = hero.querySelector('.sh-object');
  if (!cv) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  var w = cv.clientWidth, h = cv.clientHeight;
  if (!w || !h) return;

  var renderer = new THREE.WebGLRenderer({ canvas: cv, alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(w, h, false);

  var kindEarly = hero.getAttribute('data-solid') || 'ico';

  /* A tumbling solid can only ever fill 1/sqrt(1+tan^2(fov/2)) of the canvas
     height before its bounding sphere leaves the frustum: 92% at 45 degrees,
     no matter how the camera is placed. The nested cubes are asked to fill
     more of the frame than that, so they get a longer lens. */
  var FOV    = kindEarly === 'nested' ? 26  : 45;
  var BASE_Z = kindEarly === 'nested' ? 8.62 : 5.2;

  var scene = new THREE.Scene();
  var cam = new THREE.PerspectiveCamera(FOV, w / h, 0.1, 100);
  cam.position.z = BASE_Z;

  var kind = kindEarly;
  var LINE_MAT = function () {
    return new THREE.LineBasicMaterial({ color: 0xB8956A, transparent: true, opacity: 0.45 });
  };
  var DOT_MAT = function () {
    return new THREE.PointsMaterial({ color: 0xD4AF8A, size: 0.055, transparent: true, opacity: 0.85 });
  };

  var wire, pts = null, innerCube = null, recentre = null;

  if (kind === 'nested') {
    /* Two cubes, one inside the other, counter-rotating.
       EdgesGeometry rather than WireframeGeometry: the latter draws every
       triangle, so each face would show its diagonal and the whole thing
       reads as noise. This keeps 12 clean edges per cube. */
    /* A subdivided cube built by hand. BoxGeometry with segments is no use
       here: WireframeGeometry would draw every triangle diagonal, and
       EdgesGeometry merges the coplanar faces back into 12 plain edges. So
       the surface grid lines are generated directly, giving 12 x segs lines
       with no diagonals. */
    var mkCube = function (radius, segs) {
      var pos = [], corners = [], step = 2 / segs, d, a2, b2, i, j;
      for (d = 0; d < 3; d++) {
        a2 = (d + 1) % 3; b2 = (d + 2) % 3;
        for (i = 0; i <= segs; i++) {
          for (j = 0; j <= segs; j++) {
            var u = -1 + i * step, v = -1 + j * step;
            /* a line only lies on the surface if one of the other two
               coordinates is pinned to a face; otherwise it runs through
               the middle of the solid */
            if (Math.abs(u) < 0.999 && Math.abs(v) < 0.999) continue;
            var p1 = [0, 0, 0], p2 = [0, 0, 0];
            p1[d] = -1; p2[d] = 1;
            p1[a2] = u; p2[a2] = u;
            p1[b2] = v; p2[b2] = v;
            pos.push(p1[0], p1[1], p1[2], p2[0], p2[1], p2[2]);
          }
        }
      }
      for (i = 0; i < 8; i++) {
        corners.push((i & 1) ? 1 : -1, (i & 2) ? 1 : -1, (i & 4) ? 1 : -1);
      }
      var sc = radius / Math.sqrt(3);          /* unit cube's corner distance */
      for (i = 0; i < pos.length; i++) pos[i] *= sc;
      for (i = 0; i < corners.length; i++) corners[i] *= sc;

      var lg = new THREE.BufferGeometry();
      lg.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
      var pg = new THREE.BufferGeometry();
      pg.setAttribute('position', new THREE.Float32BufferAttribute(corners, 3));

      var grp = new THREE.Group();
      grp.add(new THREE.LineSegments(lg, LINE_MAT()));
      grp.add(new THREE.Points(pg, DOT_MAT()));
      return grp;
    };
    /* the outer group carries the shared tumble; the inner one is its child,
       so it inherits that and adds its own counter-spin on top */
    /* A freely tumbling cube swings between 58% and 100% of its bounding
       sphere on screen, so sizing for the worst case leaves it looking small
       most of the time. Pinning the tilt and spinning about Y only holds the
       widest moment to 94%, which buys a materially larger cube for the same
       clearance. The inner one still turns on both axes. */
    wire = new THREE.Group();
    wire.add(mkCube(2.02, 3));               /* 36 lines */
    innerCube = mkCube(2.02 * 0.52, 2);      /* 24 lines, coarser so the
                                                smaller cube does not read
                                                as a denser block */
    wire.add(innerCube);
    wire.rotation.x = 0.34;

    /* The tilt plus perspective means the silhouette's centre is not the
       origin: it rides about 19px above and below the frame centre over a
       spin, which reads as the cube drifting. Cancel it each frame by
       projecting the eight corners and offsetting to match. */
    var HALF = 2.02 / Math.sqrt(3), CORNERS = [];
    for (var c8 = 0; c8 < 8; c8++) {
      CORNERS.push([(c8 & 1) ? HALF : -HALF, (c8 & 2) ? HALF : -HALF, (c8 & 4) ? HALF : -HALF]);
    }
    var TAN_HALF = Math.tan(FOV / 2 * Math.PI / 180);
    recentre = function () {
      var cxr = Math.cos(wire.rotation.x), sxr = Math.sin(wire.rotation.x);
      var cyr = Math.cos(wire.rotation.y), syr = Math.sin(wire.rotation.y);
      var top = -1e9, bot = 1e9;
      for (var k = 0; k < 8; k++) {
        var p = CORNERS[k], x = p[0], y = p[1], z = p[2];
        /* three.js Euler XYZ applies X first, then Y */
        var y1 = y * cxr - z * sxr, z1 = y * sxr + z * cxr;
        var z2 = -x * syr + z1 * cyr;
        var yp = y1 / ((cam.position.z - z2) * TAN_HALF);
        if (yp > top) top = yp;
        if (yp < bot) bot = yp;
      }
      wire.position.y = -(top + bot) / 2 * cam.position.z * TAN_HALF;
    };
    scene.add(wire);
  } else {
    var geo;
    /* all sized to the same bounding radius (1.85) so they read at an
       identical scale across the pages, and one clearance figure covers all */
    if (kind === 'cube')       geo = new THREE.BoxGeometry(2.14, 2.14, 2.14, 2, 2, 2);
    else if (kind === 'torus') geo = new THREE.TorusGeometry(1.35, 0.5, 10, 26);
    else                       geo = new THREE.IcosahedronGeometry(1.85, 1);

    wire = new THREE.LineSegments(new THREE.WireframeGeometry(geo), LINE_MAT());
    pts = new THREE.Points(geo, DOT_MAT());
    scene.add(wire); scene.add(pts);
    if (kind === 'torus') wire.rotation.x = 0.9;
  }

  function resize() {
    w = cv.clientWidth; h = cv.clientHeight;
    if (!w || !h) return;
    cam.aspect = w / h;
    /* on a portrait canvas the horizontal field shrinks, back off so the
       solid keeps the same clearance from the frame on every side */
    cam.position.z = cam.aspect < 1 ? BASE_Z / cam.aspect : BASE_Z;
    cam.updateProjectionMatrix();
    renderer.setSize(w, h, false);
  }
  resize();
  var rt2;
  window.addEventListener('resize', function () { clearTimeout(rt2); rt2 = setTimeout(resize, 150); });

  /* stop rendering once the hero has scrolled away */
  var visible = true;
  if (window.IntersectionObserver) {
    new IntersectionObserver(function (en) { visible = en[0].isIntersecting; }).observe(hero);
  }

  (function loop() {
    requestAnimationFrame(loop);
    if (!visible) return;
    wire.rotation.y += 0.0022;
    /* the nested cubes hold their tilt so the outer one never swings
       corner-on and burst the frame; everything else tumbles freely */
    if (kind !== 'nested') wire.rotation.x += 0.0009;
    if (pts) pts.rotation.copy(wire.rotation);
    if (innerCube) { innerCube.rotation.y -= 0.0055; innerCube.rotation.x -= 0.002; }
    if (recentre) recentre();
    renderer.render(scene, cam);
  })();
})();
