# Vanguard Creative Labs — Website

A high-end, motion-led marketing site for Vanguard Creative Labs, a Sydney
systems & digital infrastructure firm operating as fractional CTOs for SMEs.

Editorial, confident, and precise — a split-screen hero, condensed display type
with serif accents, and restrained scroll-driven motion.

## Pages

| File | Purpose |
|------|---------|
| `index.html`    | Flagship homepage — hero, ticker, about, problems, difference, services, process, contact form |
| `services.html` | The four disciplines in detail + engagement model |
| `work.html`     | Selected engagements (representative case studies) |
| `about.html`    | Mission, the six brand principles, founder |
| `contact.html`  | Contact details + enquiry form |

## Structure

```
vanguard-creative-labs/
├── index.html · services.html · work.html · about.html · contact.html
├── css/styles.css        # Full design system (single stylesheet)
├── js/main.js            # Cursor · nav · GSAP/ScrollTrigger · Lenis · Three.js hero · form
└── assets/
    ├── favicon.svg
    ├── logos/            # Wordmark (navy/white), two-tone V mark, mono V watermark
    └── icons/            # Software stack logos
```

## Brand system

- **Colours** — Optical White `#F5F5F5`, Midnight Navy `#000A1F`, Warm Bronze
  `#B8956A` (primary accent), Sapphire `#1E3A72`, Steel Blue `#4A6A8A`.
- **Type** — Bebas Neue (display), Cormorant Garamond italic (serif accents),
  Exo 2 (body). Loaded from Google Fonts.
- **Voice** — senior consultant, Australian English, sentence case, SME / fractional-CTO messaging.

## Motion

GSAP + ScrollTrigger, Lenis smooth scroll, and a Three.js node-network hero —
plus a custom cursor, magnetic buttons, animated counters, a scrubbed process
timeline, and scroll reveals. Degrades for touch and `prefers-reduced-motion`.

## Running locally

No build step — it's static. Serve the folder:

```bash
python3 -m http.server 4321 --directory .
# then open http://localhost:4321
```

Libraries (GSAP 3.13, ScrollTrigger, Lenis 1.1.14, Three.js r128) load from CDN.

## Notes

- Copy is on-brand SME messaging; statistics and case studies are clearly
  representative and intended to be replaced with real figures.
- **Contact form:** wired to [Web3Forms](https://web3forms.com) (no backend
  required). It will not send until you replace `REPLACE_WITH_WEB3FORMS_KEY`
  in `js/main.js` with a free access key created for mark@vanguardcreativelabs.com.
  Until then a valid submission shows the "email us directly" fallback message.
- CSS/JS includes carry a `?v=2` cache-busting query — bump it on each release.
- The previous Oxanium/DM Sans design is backed up at
  `../_vcl-oxanium-design-backup/` (outside the web root).
```
