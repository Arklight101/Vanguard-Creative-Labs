# Case Study Intake Template

Copy everything between the `---` lines, fill it in, and send it back. One block
per case study — send as many at once as you like. Anything you leave blank I'll
flag rather than invent.

Field names map directly to the cards and slide-over panel on the Case Studies
page, so a completed block can go straight in.

---

## CASE STUDY: [short internal name, e.g. "Distributor"]

**SECTOR TAG** — appears above the card title, 2–4 words
> e.g. Wholesale & Distribution

**YEAR**
> e.g. 2025

**CARD TITLE** — the headline on the card. One line, ideally under 60 characters.
State the outcome, not the service.
> e.g. One connected system for a 40-person distributor

**CARD POINTS** — exactly 2 bullets. First = the problem, second = the result.
One sentence each.
> 1.
> 2.

**HEADLINE STATS** — exactly 2. A short figure and a 2–4 word label.
> 1. Figure: ................  Label: ................
> 2. Figure: ................  Label: ................

---

### Panel content

**CLIENT DESCRIPTOR** — anonymised, appears as the panel's title
> e.g. 40-Person Distributor

**SECTOR LINE** — sits under the title
> e.g. Wholesale & Distribution · NSW

**THE ISSUE** — 3–5 sentences. What was actually happening before you arrived:
the symptoms, who felt them, what it was costing. Concrete beats abstract —
"reconciling four systems by hand every Friday" lands, "inefficient processes"
does not.
>
>

**THE RESULTS** — 4 bullets. Measurable where you can, specific where you can't.
> 1.
> 2.
> 3.
> 4.

**HOW WE DID IT** — 5 steps, in order. Each needs a short title (2–4 words) and
one or two sentences.
> 1. Title: ................
>    Detail:
> 2. Title: ................
>    Detail:
> 3. Title: ................
>    Detail:
> 4. Title: ................
>    Detail:
> 5. Title: ................
>    Detail:

**TOOLS WE USED** — 4–6. Just name them; you do not need to supply logos.
>
> Anything already in `assets/icons/` gets used directly: Microsoft 365 ·
> Adobe Photoshop · Apple · Canva · ChatGPT · Claude · Google Drive ·
> Google Business Profile · Excel · Teams · Windows · Word · QuickBooks ·
> Salesforce · Shopify · Slack · Square · Squarespace · Xero · Zoom
>
> Anything else, I fetch the logo automatically from Iconify or Simple Icons
> and add it to the icon set. If a tool has no logo available anywhere, I set
> it as a text-only chip and tell you which one it was.
>
> 1.
> 2.
> 3.
> 4.
> 5.

**CARD IMAGE** — the photo on the card itself in the grid. Same deal.
> File: ................

---

### Optional

**TESTIMONIAL** — if this client gave you one. Goes on the testimonial cards
lower down the page.
> Quote:
> Who said it (role only):
> Backing metric:

**ENGAGEMENT TYPE** — Partnership / Build / Standalone
>

---

## Notes on what makes these land

**Anonymity.** Every study currently uses a descriptor rather than a company
name. Keep that unless you have written permission to name a client — and if you
do have it, say so explicitly and I'll use the real name and logo.

**Numbers.** Any figure that goes on the page should be one you could defend if
asked. Under Australian Consumer Law a specific claim like "11 hours saved
weekly" is a representation about your service, so it needs to be real and
substantiated, not illustrative.

**The four studies currently on the site are written by me from your existing
stats.** They read as real but I invented the narrative detail. Replacing them
with completed blocks from this template should be the priority before the site
goes public. Same goes for the three testimonials — those quotes are entirely
invented placeholders.
